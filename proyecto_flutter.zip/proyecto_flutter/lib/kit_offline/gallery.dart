import 'package:flutter/material.dart';
// Importa la librería principal de Flutter para usar widgets de Material Design

import '../app_drawer.dart';
// Importa un widget personalizado llamado AppDrawer desde otro archivo

class GalleryPage extends StatelessWidget {
  const GalleryPage({super.key});
  // Clase que representa la página de galería. Es Stateless porque no tiene estado mutable.
  
  final List<String> images = const [
    'assets/images/foto1.png',
    'assets/images/foto2.png',
    'assets/images/foto3.png',
    'assets/images/foto4.png',
  ];
  // Lista de rutas de imágenes locales que se mostrarán en la galería. 
  // 'const' hace que la lista sea inmutable.

  @override
  Widget build(BuildContext context) {
    // Método que construye la interfaz de usuario de la página
    return Scaffold(
      // Scaffold proporciona la estructura básica de la pantalla: appBar, drawer y body
      appBar: AppBar(
        title: const Text('Galería local'),
        // Título de la app bar
        centerTitle: true,
        // Centra el título en la barra
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pushReplacementNamed(context, '/project'),
          // Botón de regreso que reemplaza la página actual con la ruta '/project'
        ),
      ),
      drawer: const AppDrawer(),
      // Menú lateral personalizado importado desde app_drawer.dart
      body: Padding(
        padding: const EdgeInsets.all(12),
        // Espaciado alrededor del contenido
        child: GridView.builder(
          // GridView dinámico que construye los elementos de manera eficiente
          itemCount: images.length,
          // Número de elementos a mostrar basado en la lista de imágenes
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            // Número de columnas en la cuadrícula
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            // Espacios entre las filas y columnas
            childAspectRatio: 1,
            // Relación de aspecto de cada celda (1:1 = cuadrado)
          ),
          itemBuilder: (context, i) {
            final imgPath = images[i];
            // Obtiene la ruta de la imagen actual
            final title = imgPath.split('/').last;
            // Obtiene el nombre de la imagen usando la última parte de la ruta
            return GestureDetector(
              onTap: () {
                // Detecta toques en la imagen
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    // Muestra un cuadro de diálogo al tocar la imagen
                    title: Text(title),
                    // Título del diálogo con el nombre de la imagen
                    content: Image.asset(imgPath, fit: BoxFit.contain),
                    // Imagen en el diálogo, ajustada para caber dentro del cuadro
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        // Botón para cerrar el cuadro de diálogo
                        child: const Text('Cerrar'),
                      ),
                    ],
                  ),
                );
              },
              child: Card(
                // Cada imagen se muestra dentro de una tarjeta con sombra
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                // Bordes redondeados de la tarjeta
                elevation: 4,
                // Sombra de la tarjeta
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  // Redondea la imagen para que coincida con la tarjeta
                  child: Image.asset(imgPath, fit: BoxFit.cover),
                  // Muestra la imagen cubriendo toda la tarjeta
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
