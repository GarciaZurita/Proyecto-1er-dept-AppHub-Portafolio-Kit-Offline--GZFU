import 'package:flutter/material.dart';
// Importa la librería principal de Flutter para usar widgets de Material Design

import '../app_drawer.dart';
// Importa un widget personalizado llamado AppDrawer para el menú lateral

class KitOffline extends StatelessWidget {
  const KitOffline({super.key});
  // Clase que representa la página principal del "Kit Offline". Es Stateless porque no tiene estado mutable.

  @override
  Widget build(BuildContext context) {
    // Función que construye la interfaz de usuario
    // Dentro de build se define una función local para crear tarjetas fácilmente
    Widget tile(String title, String subtitle, IconData icon, String route) {
      // Esta función genera un Card con un ListTile para cada módulo
      return Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        // Bordes redondeados para la tarjeta
        elevation: 4,
        // Sombra de la tarjeta
        shadowColor: Colors.blueAccent.withOpacity(0.2),
        // Color de la sombra con opacidad
        child: ListTile(
          leading: Icon(icon, color: Colors.blueAccent),
          // Icono del módulo a la izquierda
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          // Título del módulo en negrita
          subtitle: Text(subtitle),
          // Descripción debajo del título
          onTap: () => Navigator.pushNamed(context, route),
          // Al tocar la tarjeta navega a la ruta especificada
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Kit Offline'), centerTitle: true),
      // Barra superior con título centrado
      drawer: const AppDrawer(),
      // Menú lateral importado
      body: Padding(
        padding: const EdgeInsets.all(16),
        // Espaciado alrededor del contenido
        child: ListView(
          // Lista de tarjetas desplazable
          children: [
            tile('Notas rápidas', 'Crear y listar notas en memoria', Icons.note_alt, '/project/notas'),
            // Primera tarjeta: módulo de notas
            tile('Calculadora de IMC', 'Form validado para calcular IMC', Icons.monitor_weight, '/project/imc'),
            // Segunda tarjeta: módulo de IMC
            tile('Galería local', 'Imágenes desde assets', Icons.photo, '/project/gallery'),
            // Tercera tarjeta: módulo de galería
            tile('Juego: Par o Impar', 'Juega contra la app', Icons.sports_esports, '/project/par_impar'),
            // Cuarta tarjeta: módulo de juego
          ],
        ),
      ),
    );
  }
}
