import 'package:flutter/material.dart';
// Importa Flutter con todos los widgets de Material Design

import '../app_drawer.dart';
// Importa el Drawer personalizado que ya creamos

class ImcPage extends StatefulWidget {
  const ImcPage({super.key});
  // Clase principal de la página IMC, Stateful porque tiene campos que cambian con la interacción del usuario

  @override
  State<ImcPage> createState() => _ImcPageState();
  // Crea el estado asociado a este widget
}

class _ImcPageState extends State<ImcPage> {
  final _formKey = GlobalKey<FormState>();
  // Clave global para identificar y validar el formulario

  final _pesoCtrl = TextEditingController();
  final _estaturaCtrl = TextEditingController();
  // Controladores para manejar el texto ingresado en los campos de peso y estatura

  @override
  void dispose() {
    _pesoCtrl.dispose();
    _estaturaCtrl.dispose();
    // Libera los recursos de los controladores al cerrar la página
    super.dispose();
  }

  // Método para calcular el IMC
  void _calcular() {
    if (!_formKey.currentState!.validate()) return;
    // Valida el formulario. Si no es válido, no hace nada

    final peso = double.parse(_pesoCtrl.text.replaceAll(',', '.'));
    final est = double.parse(_estaturaCtrl.text.replaceAll(',', '.'));
    // Convierte los valores de texto a double, reemplazando comas por puntos

    final imc = peso / (est * est);
    // Calcula el IMC usando la fórmula: peso / estatura^2

    String categoria;
    if (imc < 18.5) categoria = 'Bajo peso';
    else if (imc < 25) categoria = 'Normal';
    else if (imc < 30) categoria = 'Sobrepeso';
    else categoria = 'Obesidad';
    // Determina la categoría según el IMC

    // Mostrar el resultado en un cuadro centrado
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Resultado del IMC'),
        content: Text(
          'Tu IMC es ${imc.toStringAsFixed(1)}\nCategoría: $categoria',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18),
        ),
        actions: [
          Center(
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              // Al presionar, cierra el AlertDialog
              child: const Text('Cerrar'),
            ),
          ),
        ],
      ),
    );
  }

  // Método para limpiar el formulario
  void _limpiar() {
    _formKey.currentState!.reset();
    _pesoCtrl.clear();
    _estaturaCtrl.clear();
    // Limpia los campos de texto
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculadora de IMC'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pushReplacementNamed(context, '/project'),
          // Botón de regreso que reemplaza la página actual con '/project'
        ),
      ),
      drawer: const AppDrawer(),
      // Menú lateral personalizado
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        // Permite que la pantalla sea desplazable y agrega padding
        child: Form(
          key: _formKey,
          // Asociamos la clave global al formulario
          child: Column(
            children: [
              TextFormField(
                controller: _pesoCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                // Campo de texto para el peso, permite decimales
                decoration: const InputDecoration(
                  labelText: 'Peso (kg)',
                  prefixIcon: Icon(Icons.monitor_weight),
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Obligatorio';
                  final n = double.tryParse(v.replaceAll(',', '.'));
                  if (n == null || n <= 0) return 'Número válido mayor a 0';
                  return null;
                  // Valida que el campo no esté vacío y sea un número positivo
                },
                textInputAction: TextInputAction.next,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _estaturaCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                // Campo de texto para la estatura
                decoration: const InputDecoration(
                  labelText: 'Estatura (m)',
                  prefixIcon: Icon(Icons.height),
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Obligatorio';
                  final n = double.tryParse(v.replaceAll(',', '.'));
                  if (n == null || n <= 0) return 'Número válido mayor a 0';
                  return null;
                  // Validación similar al peso
                },
                textInputAction: TextInputAction.done,
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: _calcular,
                    icon: const Icon(Icons.calculate),
                    label: const Text('Calcular'),
                    // Botón para calcular el IMC
                  ),
                  OutlinedButton.icon(
                    onPressed: _limpiar,
                    icon: const Icon(Icons.clear),
                    label: const Text('Limpiar'),
                    // Botón para limpiar el formulario
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
