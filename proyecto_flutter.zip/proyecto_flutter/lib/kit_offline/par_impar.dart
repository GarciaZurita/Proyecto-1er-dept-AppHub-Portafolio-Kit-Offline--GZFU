import 'dart:math';
// Importa la librería math para generar números aleatorios (Random)

import 'package:flutter/material.dart';
// Importa la librería principal de Flutter

import '../app_drawer.dart';
// Importa un widget personalizado llamado AppDrawer para el menú lateral

class ParImparPage extends StatefulWidget {
  const ParImparPage({super.key});
  // Widget principal del juego. Es Stateful porque el puntaje cambia durante el juego.

  @override
  State<ParImparPage> createState() => _ParImparPageState();
  // Crea el estado asociado
}

class _ParImparPageState extends State<ParImparPage> {
  final Random _rnd = Random();
  // Generador de números aleatorios para la CPU

  int _puntosUsuario = 0;
  int _puntosCPU = 0;
  // Variables para llevar el marcador

  String? _resultado;
  // Variable para almacenar el resultado de la última ronda

  void _jugar(bool elegirPar, int numeroUsuario) {
    final cpu = _rnd.nextInt(6);
    // La CPU elige un número aleatorio del 0 al 5

    final suma = numeroUsuario + cpu;
    // Calcula la suma del número del usuario y la CPU

    final esPar = suma % 2 == 0;
    // Determina si la suma es par

    final usuarioGana = (esPar && elegirPar) || (!esPar && !elegirPar);
    // Verifica si el usuario gana según su elección (Par o Impar)

    final mensaje =
        'Tu: $numeroUsuario — CPU: $cpu → Suma $suma (${esPar ? 'Par' : 'Impar'}) — ${usuarioGana ? 'Ganaste' : 'Perdiste'}';
    // Mensaje que se mostrará en la pantalla

    if (usuarioGana) _puntosUsuario++;
    else _puntosCPU++;
    // Actualiza el marcador

    setState(() {
      _resultado = mensaje;
      // Actualiza la variable de resultado para mostrar en pantalla
    });
  }

  void _reiniciar() {
    setState(() {
      _puntosUsuario = 0;
      _puntosCPU = 0;
      _resultado = null;
      // Reinicia marcador y oculta el resultado
    });
  }

  void _cerrarResultado() {
    setState(() {
      _resultado = null;
      // Oculta el resultado
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Juego: Par o Impar'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pushReplacementNamed(context, '/project'),
        ),
      ),
      drawer: const AppDrawer(),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                'Elige un número (0–5) y luego Par o Impar',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: List.generate(6, (i) {
                  return ElevatedButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: Text('¿Par o Impar con número $i?'),
                          actions: [
                            ElevatedButton(
                              onPressed: () {
                                Navigator.pop(context);
                                _jugar(true, i);
                              },
                              child: const Text('Par'),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                Navigator.pop(context);
                                _jugar(false, i);
                              },
                              child: const Text('Impar'),
                            ),
                          ],
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text('$i'),
                  );
                }),
              ),
              const SizedBox(height: 24),
              Text(
                'Marcador: Usuario $_puntosUsuario — CPU $_puntosCPU',
                style: const TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: _reiniciar,
                icon: const Icon(Icons.refresh),
                label: const Text('Reiniciar marcador'),
              ),
              const SizedBox(height: 24),
              // Muestra el resultado en medio si existe
              if (_resultado != null)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  color: Colors.blueAccent.withOpacity(0.1),
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Text(
                          _resultado!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton(
                          onPressed: _cerrarResultado,
                          child: const Text('Cerrar resultado'),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
