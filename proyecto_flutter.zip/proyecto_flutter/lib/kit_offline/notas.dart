import 'package:flutter/material.dart';
// Importa la librería principal de Flutter para widgets de Material Design

import '../app_drawer.dart';
// Importa el menú lateral personalizado

class NotasPage extends StatefulWidget {
  const NotasPage({super.key});
  // Clase principal de la página de notas. Es Stateful porque el contenido cambia dinámicamente.

  @override
  State<NotasPage> createState() => _NotasPageState();
  // Crea el estado asociado
}

class _NotasPageState extends State<NotasPage> {
  final List<String> _notas = [];
  // Lista para almacenar las notas en memoria

  void _agregarNota() async {
    final controlador = TextEditingController();
    // Controlador para capturar el texto ingresado en el diálogo

    final result = await showDialog<String>(
      context: context,
      builder: (_) {
        return AlertDialog(
          title: const Text('Nueva nota'),
          content: TextField(
            controller: controlador,
            maxLength: 120,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: 'Escribe algo corto',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
            ElevatedButton(onPressed: () => Navigator.pop(context, controlador.text.trim()), child: const Text('Agregar')),
          ],
        );
      },
    );
    // Muestra un cuadro de diálogo para ingresar una nueva nota. 
    // Si el usuario presiona "Agregar", devuelve el texto; si presiona "Cancelar", devuelve null.

    if (result != null && result.isNotEmpty) {
      setState(() => _notas.insert(0, result));
      // Inserta la nueva nota al inicio de la lista y actualiza la UI
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nota agregada')));
      // Muestra un mensaje temporal confirmando que la nota se agregó
    }
  }

  void _borrarTodo() {
    if (_notas.isEmpty) return;
    // Si no hay notas, no hace nada
    setState(() => _notas.clear());
    // Limpia la lista de notas y actualiza la UI
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Todas las notas borradas')));
    // Muestra mensaje de confirmación
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notas rápidas'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pushReplacementNamed(context, '/project'),
          // Botón de regreso
        ),
        actions: [
          IconButton(onPressed: _borrarTodo, icon: const Icon(Icons.delete_forever)),
          // Botón para borrar todas las notas
        ],
      ),
      drawer: const AppDrawer(),
      floatingActionButton: FloatingActionButton(
        onPressed: _agregarNota,
        child: const Icon(Icons.add),
        // Botón flotante para agregar una nueva nota
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: _notas.isEmpty
            ? const Center(child: Text('No hay notas. Presiona + para agregar.'))
            // Si no hay notas, muestra un mensaje centrado
            : ListView.builder(
                itemCount: _notas.length,
                itemBuilder: (context, i) {
                  final n = _notas[i];
                  return Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 3,
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    child: ListTile(
                      title: Text(n),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () {
                          setState(() => _notas.removeAt(i));
                          // Elimina la nota seleccionada
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nota eliminada')));
                        },
                      ),
                    ),
                  );
                },
              ),
        // Lista de notas mostrada en tarjetas. Cada tarjeta tiene un botón de borrar individual.
      ),
    );
  }
}
